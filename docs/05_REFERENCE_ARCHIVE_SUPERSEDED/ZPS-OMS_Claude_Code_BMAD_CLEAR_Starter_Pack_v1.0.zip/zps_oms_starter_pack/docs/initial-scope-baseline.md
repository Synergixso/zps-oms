# ZPS-OMS initial scope baseline

**Status:** Draft for discovery and institutional validation  
**Date:** 24 November 2026

## Product definition
ZPS-OMS is a proposed internal administrative operations-support system for the Office of the Deputy Inspector General – Operations (DIG Ops), the ten Provincial Police Divisions, and the directorates/divisions/units/formations confirmed as overseen by that office.

## In-scope organisational layers
1. DIG Ops at Service Headquarters.
2. Provincial Police Divisions: Lusaka, Copperbelt, Central, Southern, Eastern, Northern, Luapula, North-Western, Western and Muchinga.
3. DIG Ops formations and directorates. User-identified examples: Mobile Unit/SPOM, Paramilitary Battalion, Protective Unit, Airport Division and TAZARA Division. Public Zambia Police sources additionally identify Crime Prevention and Support Services Directorate, Police Air Wing and National Command Centre.

## Boundary exclusions
- District offices, stations and posts;
- DIG Administration and DIG Special Duties structures;
- Separate national Training Management System;
- Public-facing citizen services;
- Intelligence, informants, surveillance, live tracking, patrol routes, tactical deployments, operational tasking/dispatch, case management, evidence, firearms/armoury, and tactical equipment management.

## Core capability candidates
- Approved organisation directory and reporting relationships;
- Identity and access administration;
- Administrative task/request/approval workflow;
- Non-sensitive fleet register and maintenance history;
- Non-sensitive general asset accountability;
- Limited administrative availability/scheduling, only after specific approval;
- Aggregate management reporting;
- Auditable administration and records metadata where authorised.

## Evidence status
- Public-source fact: ZPS public page says the DIG Ops office coordinates police operations functions and oversees provinces and specified directorates/units.
- Public-source fact: the public DIG Ops Appendix D organogram shows an intermediate Commissioner of Police position followed by eight subordinate positions.
- User-provided project decision: software scope is limited to Service Headquarters under DIG Ops, Provincial Divisions and Divisional Units/formations; no districts/stations/posts.
- Validation required: approved internal hierarchy, official current titles, formation list, delegations, business processes, data classification, hosting, security approval and retention rules.
- Hypothesis only: paper registers, delays, duplicated records, missing visibility, or inconsistent reporting may exist; validate through authorised discovery, do not state as fact.
