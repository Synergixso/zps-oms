# ZPS-OMS Project Documentation Register

This folder is the controlled documentation home for the proposed Zambia Police Service Operations Management System.

## Planning artifacts to create/maintain through BMad
- `product-brief.md` — problem, outcomes, scope and stakeholders.
- `prd.md` — approved requirements and acceptance criteria.
- `ux-spec.md` — experience principles, screen inventory and user journeys.
- `architecture.md` — target architecture and deployment boundaries.
- `adr/` — numbered architecture decision records.
- `organisation-catalogue.md` — institution-approved in-scope hierarchy and effective dates.
- `permission-matrix.md` — roles, actions and organisational scopes.
- `data-dictionary.md` and `erd/` — fields, relationships, classifications and retention.
- `threat-model.md` — assets, threats, trust boundaries and mitigations.
- `data-flow-register.md` — source, purpose, recipients, hosting and transfers.
- `api-contract.yaml` — approved API specification.
- `epics-and-stories.md` or generated BMad story files — delivery backlog.
- `traceability-matrix.md` — requirement/story/test mapping.
- `test-strategy.md` and `test-evidence/` — automated and manual test records.
- `deployment-runbook.md`, `backup-recovery-runbook.md`, `incident-response-runbook.md`.
- `assumptions-register.md`, `open-decisions.md`, `risk-register.md`, `source-register.md`.

Do not mark a document approved unless the appropriate institutional approver has formally approved it. Use statuses such as Draft, Under Review, Approved, Superseded.
