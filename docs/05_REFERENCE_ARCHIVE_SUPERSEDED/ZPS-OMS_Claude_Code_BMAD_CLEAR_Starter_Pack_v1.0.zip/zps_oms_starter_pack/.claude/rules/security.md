# ZPS-OMS security and data-handling rules

- Development uses synthetic data only.
- Never introduce a feature that manages intelligence, informants, surveillance, tactical deployments, routes, dispatch, operational case details, evidence, armoury/firearms, tactical kit, or live officer location.
- All endpoints enforce server-side authorisation and organisational scope; do not trust client-supplied organisation IDs.
- Deny by default. Validate requested resource scope against the authenticated user's effective grants.
- Prevent insecure direct object reference (IDOR) and cross-formation leakage.
- Do not expose detailed data in national dashboards unless the user has explicit record-level authority; prefer aggregate reporting.
- Keep technical administrator, security auditor, and business-record roles separate.
- Never store secrets in source control, prompts, fixtures, logs, or screenshots.
- Do not call external APIs or send telemetry without an approved data-flow assessment.
- Require explicit approval before applying migrations to any shared database or deploying to any environment other than an isolated local/dev environment.
