# ZPS-OMS scope and organisational boundary

The product covers only the Office of the Deputy Inspector General – Operations at Service Headquarters, Provincial Police Divisions, and directorates/divisions/units/formations formally confirmed as overseen by that office.

It does not cover districts, stations, posts, DIG Administration, DIG Special Duties, national training management, public e-services, crime/case management, intelligence, surveillance, dispatch, tactical operations, or evidence management.

The initial organisational catalogue may include, subject to confirmation: Lusaka, Copperbelt, Central, Southern, Eastern, Northern, Luapula, North-Western, Western and Muchinga Provincial Divisions; Paramilitary Battalion; TAZARA Division; SPOM/Mobile Unit; Protective Unit; Airport Division; Crime Prevention and Support Services Directorate; Police Air Wing; and National Command Centre.

Do not assume all these formations share the same reporting line, data permissions, or business workflows. Store organisational relationships as versioned, effective-dated configuration approved by the institution.
