---
name: zps-oms-quality-gate
description: Run the ZPS-OMS project quality, scope, security, and test checks before marking a story complete.
---

# ZPS-OMS Quality Gate

1. Read the story acceptance criteria and linked requirements.
2. Confirm the change stays within approved ZPS-OMS scope and does not introduce excluded operational capabilities.
3. Inspect server-side permission checks for every new or changed endpoint and data access path.
4. Add or update tests for positive permissions, denied permissions, cross-province/formation denial, audit events, validation, and error cases as relevant.
5. Run formatting, lint, typecheck, targeted tests, integration tests, build, and E2E checks available in the repository.
6. Review database migrations for reversibility, data-loss risk, indexes, constraints, and transaction safety.
7. Summarise commands and actual results. List failures and untested areas explicitly. Never mark the story done if a required gate is failing.
