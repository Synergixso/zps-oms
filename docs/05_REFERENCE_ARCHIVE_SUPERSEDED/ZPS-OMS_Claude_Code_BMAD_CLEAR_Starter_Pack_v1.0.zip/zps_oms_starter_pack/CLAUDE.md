# ZPS-OMS — Claude Code Project Instructions

## Project identity and authority boundary
- Project: Zambia Police Service Operations Management System (ZPS-OMS).
- This repository is for a proposed administrative operations-support platform. It is not an operational command, intelligence, surveillance, dispatch, case-management, evidence, or tactical deployment system.
- The intended institutional scope is the Office of the Deputy Inspector General – Operations (DIG Ops) at Service Headquarters, the ten Provincial Police Divisions, and the authorised directorates/divisions/units/formations overseen by that office.
- It explicitly excludes district offices, police stations, police posts, the DIG Administration and DIG Special Duties structures, and the separate national Training Management System unless the project owner later changes the scope through a formally approved change request.
- The user has identified formations including Mobile Unit/SPOM, Paramilitary Battalion, Protective Unit, Airport Division and TAZARA Division. Public ZPS information also lists Crime Prevention and Support Services Directorate, Police Air Wing and National Command Centre. Treat the organisational register as configurable and the final hierarchy as subject to written confirmation from the approved establishment.

## Non-negotiable safety and scope constraints
- Use only synthetic or explicitly approved test data. Never ask for, ingest, reproduce, or commit real police personnel, duty, fleet, asset, location, operational, intelligence, case, informant, or security information into this development repository or an unapproved AI service.
- Never implement intelligence records, informant management, surveillance, live officer tracking, patrol routes, tactical deployment planning, dispatch, mission/tasking details, operational incident details, case files, evidence/exhibits, armoury/firearms records, tactical equipment detail, vulnerability maps, or capabilities that reveal operational readiness or deployment patterns.
- Administrative scheduling, if approved, must be limited to non-tactical administrative availability/scheduling metadata. Do not store operational locations, routes, mission purpose, deployment details, or detailed shift patterns in an externally accessible or unapproved environment.
- No production deployment, external network exposure, production credential use, data import, real identity integration, or connection to police networks without formal written institutional authorisation and security approval.
- No destructive database operations, data migrations against shared environments, deletion of records, bulk exports, or external service activation without explicit human approval.
- Deny by default. Enforce authorisation on the server for every protected operation. UI hiding is not access control.

## Engineering approach
- Follow the BMad Method workflow gates. Do not jump directly to feature coding before the approved discovery, PRD, UX, architecture, epics/stories, and readiness artifacts exist.
- Use CLEAR quality criteria for prompts and deliverables: Concise, Logical, Explicit, Adaptive, Reflective.
- Treat stakeholder assumptions as assumptions. Maintain an assumptions register, decision log, risk register, source register, and traceability from requirement to story to test.
- Inspect the existing repository before proposing changes. Preserve existing technology choices unless a documented architecture decision approves a change.
- Prefer a modular monolith for the first release unless measured requirements justify a more distributed architecture.
- Keep business logic out of UI components. Validate inputs at API boundaries and persist critical state transitions transactionally.
- Use typed contracts, schema validation, migrations, automated tests, structured logs, and meaningful error handling.
- Every feature must include loading, empty, validation, success, failure, permission-denied, and audit behaviours where applicable.

## Security engineering rules
- Use secure session management, MFA where approved, strong password/identity policies, CSRF protection where relevant, secure cookies, rate limiting, input validation, output encoding, and secure headers.
- Use RBAC plus organisational-scope attributes (ABAC) where needed. A user must be restricted by role, function, and assigned organisational scope.
- Separate technical administration from business-data access. A platform administrator does not automatically gain access to personnel or other restricted business records.
- Record security-relevant and business-critical actions in append-only/tamper-evident audit events. Do not put secrets or sensitive personal data in logs.
- Encrypt traffic in transit and data at rest using institution-approved key management. Never invent or hard-code cryptographic keys.
- Do not add offline caching or local storage of sensitive data unless specifically approved and protected by managed-device controls.
- External integrations must be disabled by default and require a documented data-flow assessment and written approval.

## Claude Code working protocol
1. Start in Plan Mode for discovery, architecture, and risky changes.
2. Read the relevant BMad artifacts and applicable `.claude/rules/` before making changes.
3. State the intended files and tests before implementation.
4. Implement one approved story or small coherent change at a time.
5. Run the smallest relevant checks first, then full quality gates before declaring completion.
6. Report exactly what changed, commands run, tests passed/failed, known gaps, and outstanding decisions.
7. Do not claim a test, audit, deployment, security assessment, or approval occurred unless it actually occurred.

## Quality gates
- Formatting/lint passes.
- Type checking passes.
- Unit and integration tests pass for changed logic.
- Permission tests cover allowed and denied access, including cross-organisation access denial.
- Audit-log tests cover sensitive state transitions.
- Migration tests prove forward migration and rollback strategy in a disposable test database.
- Build passes.
- For UI changes, run browser/E2E tests where available and inspect screenshots at desktop and mobile widths.
- Security review finds no unresolved critical/high issue before a release candidate.

## Project documentation locations
- `docs/` — approved requirements, UX, architecture, decisions, data dictionary, test strategy, release notes.
- `prompts/` — versioned prompts used with Claude Code/BMad.
- `.claude/rules/` — persistent focused project rules.
- `.claude/skills/` — repeatable project procedures.
- `tests/` — automated tests and synthetic fixtures.
- `scripts/` — repeatable local development and QA tooling.

## Current status
- This is a planning baseline, not an approved government system specification.
- All organisation names, hierarchy links, business workflows, data classifications, retention periods, service targets, hosting choices, and integrations require institutional validation and approval.
