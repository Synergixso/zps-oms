# Claude Code session 1 — repository discovery and BMAD initialisation

Start in Plan Mode. You are working on ZPS-OMS. Read `CLAUDE.md`, `.claude/rules/scope.md`, `.claude/rules/security.md`, and `prompts/master-project-prompt.md` in full. Inspect the repository without modifying application code. Identify current stack, project structure, tests, environment files (do not print secrets), deployment assumptions, existing modules, and whether this is greenfield or an existing system.

Then inspect the installed BMad Method version and supported workflows for Claude Code. Do not assume command names from memory; use the installed workflow/agent menus and current local BMad documentation. Prefer the stable BMad line when reliability is required and verify the official current release before installing/upgrading.

Create the first Analysis artifacts in `docs/`: product-brief.md, stakeholder-map.md, assumptions-register.md, open-decisions.md, risk-register.md, source-register.md, and repository-assessment.md. Keep all requirements in the defined ZPS-OMS scope. Clearly label user-provided context, public-source facts, hypotheses and decisions pending institutional approval. Use synthetic examples only. Do not implement application features in this session.

Finish with: artifacts created, findings, unresolved questions, scope issues, risks, and the exact next BMad workflow. Stop for human review.
