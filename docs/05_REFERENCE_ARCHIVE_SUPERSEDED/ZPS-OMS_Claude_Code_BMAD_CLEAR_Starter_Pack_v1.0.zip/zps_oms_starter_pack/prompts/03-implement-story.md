# Claude Code / BMad — implement one approved story

Implement only the specific approved ZPS-OMS story provided in this session. First read the linked PRD requirement, UX specification, architecture decisions, permission matrix, threat model and story acceptance criteria. Confirm no excluded capability or unapproved data class is involved.

Before coding, summarise the intended files, data changes, API/UI changes, permission checks, audit events and tests. Use Plan Mode for any architectural, schema or destructive change. Implement a small vertical slice. Use synthetic fixtures only. Enforce authorisation server-side and test both allowed and denied cases, especially cross-division/cross-formation access. Add unit/integration/E2E tests appropriate to the story. Review migrations for constraints, indexes, rollback strategy and data-loss risk. Do not deploy or connect external services.

Run formatting, lint, typecheck, targeted tests, integration tests and build as available. Report actual commands and outcomes. If a required test fails, fix it or clearly mark the story incomplete. Update traceability and release notes. Stop before the next story.
