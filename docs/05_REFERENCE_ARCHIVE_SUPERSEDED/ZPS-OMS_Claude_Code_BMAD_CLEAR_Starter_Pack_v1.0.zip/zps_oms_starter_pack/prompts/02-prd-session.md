# Claude Code / BMad — PRD creation and validation prompt

Using the approved product brief, stakeholder map, discovery notes and open-decisions register, create or update the ZPS-OMS Product Requirements Document through the installed BMad Product Manager workflow.

Requirements:
- Use the precise organisational scope in the master prompt.
- Separate DIG Ops HQ, Provincial Divisions, and authorised directorates/units as organisational branches; do not assume every unit reports through the same direct line unless the approved establishment confirms this.
- Exclude districts, stations, posts, DIG Administration, DIG Special Duties, the separate Training Management System and all prohibited operational capabilities.
- For every feature include requirement ID, description, priority, actor, preconditions, main flow, alternate/error flow, data handled, classification, scope rules, audit events, acceptance criteria, dependencies and release phase.
- Add non-functional requirements with measurable targets only where stakeholders or infrastructure evidence support them; otherwise label targets as proposals for validation.
- Include RBAC/ABAC, server-side enforcement, tenant/organisation boundary tests, data minimisation, records retention, auditability, accessibility, low-bandwidth performance, backup/recovery, security, monitoring, change management and support.
- Define MVP versus later releases. Do not expand scope to make the PRD look comprehensive.
- Include assumptions and unresolved decisions; do not silently fill legal, operational or organisational gaps.
- Validate internal consistency and produce review findings before marking the PRD ready.

Use CLEAR: Concise (no filler), Logical (requirements in coherent order), Explicit (testable statements), Adaptive (record unresolved decisions), Reflective (review for contradictions and evidence gaps).
