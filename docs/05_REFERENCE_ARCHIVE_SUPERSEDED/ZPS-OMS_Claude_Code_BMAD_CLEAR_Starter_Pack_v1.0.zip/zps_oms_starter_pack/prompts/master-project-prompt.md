# ZPS-OMS — Master Project Prompt for Claude Code

**Prompt version:** 1.0  
**Status:** Planning baseline — institutional validation required  
**Date:** 24 November 2026  
**Target tool:** Claude Code  
**Delivery method:** BMad Method with CLEAR prompt-quality controls

## C — Concise: project identity

You are assisting with the analysis, specification, architecture, implementation planning, controlled development, and verification of the Zambia Police Service Operations Management System (ZPS-OMS).

ZPS-OMS is a proposed internal administrative operations-support platform. Its scope is deliberately restricted to:

1. The Office of the Deputy Inspector General – Operations (DIG Ops) at Zambia Police Service Headquarters;
2. The ten Provincial Police Divisions; and
3. The directorates, divisions, units, and formations formally confirmed as falling under the DIG Ops remit.

The user has specifically identified Mobile Unit/SPOM, Paramilitary Battalion, Protective Unit, Airport Division, and TAZARA Division, among others. The public Zambia Police website also identifies Crime Prevention and Support Services Directorate, Police Air Wing, and National Command Centre as formations overseen by the DIG Ops office. Treat this catalogue as a discovery baseline, not a final approved establishment. The approved internal establishment and current command instrument take precedence.

## L — Logical: work in the following sequence

Do not begin with feature coding. Proceed through the BMad Method lifecycle and preserve each approved artifact in the repository:

### Phase 1 — Analysis
- Inspect the repository and determine whether this is a greenfield project or an existing codebase.
- Establish a concise product brief, business problem hypotheses, stakeholder map, user groups, process-discovery plan, assumptions register, dependencies, risks, and source register.
- Separate verified public facts from user-provided context, working hypotheses, and decisions requiring written approval.
- Validate the Office of DIG Ops scope against current official documents, especially Appendix D, and record any inconsistency in titles or reporting lines.

### Phase 2 — Planning
- Create a detailed PRD with product goals, non-goals, personas, functional requirements, non-functional requirements, data classification, workflows, permissions, acceptance criteria, KPIs, and release boundaries.
- Create a UX specification and accessible screen inventory for national HQ, provincial, and formation-level users.
- Build the role/permission/organisation-scope matrix.
- Create a traceable product backlog with epics, features, and small testable user stories.

### Phase 3 — Solutioning
- Produce system architecture, context/container/component diagrams, deployment model, data model, API contracts, event/audit design, security threat model, backup/DR plan, and Architecture Decision Records (ADRs).
- Evaluate a modular monolith before microservices. Explain any decision to use a different architecture.
- Design the organisational hierarchy as configurable, effective-dated data, not hard-coded role logic.
- Complete a readiness assessment across PRD, UX, architecture, stories, security, infrastructure, governance and testability.

### Phase 4 — Implementation and verification
- Implement only approved stories, one coherent slice at a time.
- Use synthetic data in development and test environments.
- Add tests as part of each story, not as a final activity.
- Review code and verify requirements-to-tests traceability.
- Maintain release notes, known issues, and a retrospective.

Use the installed BMad release's actual menus and workflow identifiers. Do not invent command names. Prefer the stable release when the repository requires predictable workflows; verify the current official version before installation. As checked on 24 November 2026, the official BMad site presents v6.12.0 as the stable release and identifies the newer line as preview/alpha in its current project material. Recheck before setup.

## E — Explicit: product scope and hard exclusions

### Included organisational scope

**A. DIG Ops Headquarters layer**
- Approved administrative coordination and oversight for the DIG Ops office.
- National administrative dashboards and consolidated reports.
- Management of approved organisational units and reporting links.
- Workflow oversight, overdue administrative items, and audit summaries.

**B. Provincial Police Divisions**
- Ten configurable provincial divisions: Lusaka, Copperbelt, Central, Southern, Eastern, Northern, Luapula, North-Western, Western, and Muchinga.
- Division-level administrative dashboards and workflows.
- Provincial fleet/general asset administration and approved administrative requests.
- Reporting upward to national HQ within assigned permissions.

**C. DIG Ops directorates/units/formations**
- User-identified examples: SPOM/Mobile Unit, Paramilitary Battalion, Protective Unit, Airport Division, TAZARA Division.
- Publicly listed further examples to validate: Crime Prevention and Support Services Directorate (including relevant functions), Police Air Wing, National Command Centre.
- Additional or renamed formations can be entered only by an authorised organisational administrator with documented approval and effective dates.

### Excluded organisational scope
- District offices, police stations, and police posts are outside this product boundary.
- DIG Administration and DIG Special Duties structures are outside this product boundary.
- The separate national Training Management System is outside this product.
- Do not create user accounts or operational workflows for excluded organisations unless scope changes through an approved change request.

### Included product capabilities (subject to validation)
1. Organisational directory and formation register.
2. User identity, role, permission and organisation-scope administration.
3. Administrative requests, task registers, approvals and status tracking.
4. Fleet register, maintenance requests, service history, non-sensitive compliance dates and administrative expenditure records.
5. General non-sensitive asset register, custody, issue/return and maintenance.
6. Non-tactical administrative availability and scheduling metadata only, if separately approved.
7. Non-sensitive internal correspondence/document metadata and controlled filing, if approved.
8. Aggregate administrative dashboards and reporting.
9. Audit and security administration.

### Absolute exclusions
Do not design, prototype, simulate, seed or implement:
- Intelligence or crime intelligence records;
- Informant/covert source management;
- Surveillance or monitoring capabilities;
- Live officer/vehicle tracking, GPS telemetry, location history or route capture;
- Patrol planning, tactical deployment, response tactics, mission orders, live operational tasking or dispatch;
- Operational incident narratives, criminal investigation files, case management or evidence/exhibit management;
- Firearms/armoury data or detailed inventories of controlled tactical equipment;
- Operational readiness analytics that reveal deployment capability, unit vulnerabilities, staffing gaps, or deployment patterns;
- Public-facing policing services or citizen complaint management;
- National training administration or personnel payroll.

If a proposed feature might reveal sensitive operational capability, stop, explain the risk, and propose a safer administrative alternative. Do not implement it by default.

## Data sensitivity and handling

Use only synthetic data until the institution has approved classification, legal basis, retention, hosting, access, security, and data-processing arrangements. The business owner and competent information-security authority must approve the classification model. Default to collecting the minimum data needed. National dashboards should favour aggregate data. Do not store high-sensitivity operational information in this system.

## Required product outcomes

The system should help authorised users:
- Maintain a reliable and approved directory of in-scope formations;
- Process routine administrative requests with traceable ownership and status;
- Improve vehicle maintenance record completeness and service follow-up;
- Improve accountability for general non-sensitive assets;
- Reduce manual report preparation effort;
- Provide auditable approvals and change history;
- Give national management a controlled, accurate summary of administrative support performance.

Do not assert that current processes are paper-based, inefficient, duplicated or delayed unless validated. Treat such points as hypotheses to test with authorised stakeholders.

## Architecture constraints and preferred starting point

- Use a modular monolith initially unless requirements and measured operational needs justify service separation.
- Keep the frontend, backend, database, files and identity provider within an institution-approved deployment boundary.
- Proposed stack for evaluation: Next.js + TypeScript frontend; TypeScript API/backend such as NestJS; PostgreSQL; approved object/document storage; institution-approved identity provider; central logging/monitoring; encrypted backups and secondary recovery environment.
- These are proposals, not approved decisions. Compare them against Government ICT standards, existing Zambia Police/SMART Zambia infrastructure, staff capability, supportability, procurement/licensing, and hosting restrictions.
- Do not assume commercial cloud, a particular hosting vendor, Supabase, Vercel, Netlify, or third-party email/SMS services are approved for police information.
- Support low bandwidth. Offline support is not a default: only non-sensitive draft data may be considered, and only after security approval.
- Enforce row/record access on the server. Consider database row-level security as defence in depth, but do not rely on it as the only control.
- Use versioned APIs, schema validation, database constraints, transactional workflows and idempotency for state-changing operations.

## Security and governance requirements

- Deny by default; least privilege; separation of duties; unique accounts; MFA where approved; secure sessions; strong authentication; encryption at rest/in transit; managed keys; secure backups; tested restoration; vulnerability management; dependency scanning; audit trails; incident response; retention and disposal; access recertification.
- Enforce role + function + organisational-scope rules. Do not trust organisation IDs from the browser. Prevent cross-division and cross-formation IDOR.
- Technical administrators must not automatically gain business-record access.
- Audit access grants, revocations, approvals, changes to organisational relationships, exports, privileged actions, and critical workflow state changes.
- Do not log passwords, tokens, sensitive personal data or document contents unnecessarily.
- External interfaces, integrations and telemetry remain disabled until data-flow, security and legal approvals are documented.
- No deployment to a police network or production environment without written institutional authorisation.

## Architecture and data entities to evaluate

At minimum, evaluate these conceptual entities without assuming they all belong in MVP:
- OrganisationUnit, OrganisationUnitType, OrganisationRelationship, OrganisationAssignment, EffectiveDate;
- User, IdentityReference, Role, Permission, RoleAssignment, ScopeGrant, AccessReview;
- AdministrativeRequest, WorkflowDefinition, WorkflowStep, Approval, Comment, AttachmentReference;
- FleetAsset, VehicleComplianceRecord, MaintenanceRequest, ServiceRecord, WorkshopReference;
- GeneralAsset, AssetCategory, CustodyAssignment, AssetMovement, AssetCondition;
- AdministrativeTask, TaskStatus, TaskAssignment, DueDate;
- DocumentRegisterEntry, CorrespondenceReference, RetentionCategory;
- AuditEvent, SecurityEvent, ReportDefinition, NotificationPreference.

For each entity define ownership, classification, allowed operations, relationships, retention, audit requirements and organisational scope.

## User roles to evaluate

- DIG Ops executive viewer/approver;
- National Operations Secretariat/authorised HQ coordinator;
- National functional administrator (fleet/assets/workflows/reports);
- Provincial Division Commander;
- Provincial administrative/operations officer;
- Formation/Unit Commander;
- Formation/Unit administrative officer;
- Fleet/transport officer;
- General asset custodian/stores officer (non-sensitive assets only);
- Read-only auditor;
- Application administrator;
- Security administrator.

These are proposed roles. Confirm official titles and delegated approval authorities before configuring production roles. Avoid broad catch-all administrator access.

## Acceptance criteria examples

- A provincial user cannot read or update another province's records by changing an identifier or API payload.
- A unit user can access only the unit's authorised scope and approved shared records.
- A central user sees only national data and detail fields explicitly authorised for that role.
- Changing organisational reporting relationships is permission-controlled, effective-dated and audited.
- A maintenance request has traceable submitter, approver, state transitions, timestamps and closure evidence.
- Fleet maintenance reports exclude vehicle live location, routes and operational deployments.
- Every permission denial is safe, does not leak the existence or contents of an unauthorised record, and is covered by tests.
- Every export is permission-checked, logged and limited to approved fields.
- Audit records cannot be edited or deleted through ordinary application roles.
- No excluded capability appears in navigation, database schema, API contracts, test fixtures or demo data.

## A — Adaptive: how to handle unknowns

- If critical information is missing, create a clearly labelled question in `docs/open-decisions.md` and continue with a safe, reversible assumption only where possible.
- Do not invent official titles, reporting lines, delegations, retention periods, hosting standards, legal bases, data classifications or service-level targets.
- When public sources conflict with the user-approved project scope, follow the user's scope for product boundaries but note the discrepancy for institutional validation.
- Use discovery interviews and process walkthroughs to validate each pain point. Do not convert hypotheses into requirements without evidence or stakeholder approval.
- Break large work into small stories. Prefer vertical slices with tests and documentation.

## R — Reflective: review and evidence

For every major artifact and implementation increment:
- Check consistency with the approved scope;
- Identify missing decisions and unsupported assumptions;
- Review security and privacy impacts;
- Trace requirements to stories and tests;
- Run relevant quality gates;
- Review accessibility, responsive layout, errors and permission-denied states;
- Record lessons and update the decision/assumption/risk logs.

## Required deliverables in the repository

1. Product brief and stakeholder map.
2. Validated PRD.
3. UX specification and screen inventory.
4. Approved organisation hierarchy catalogue and role/scope permission matrix.
5. Architecture document and ADRs.
6. Data dictionary and ERD.
7. Threat model and security controls matrix.
8. Data classification, retention and data-flow register.
9. API contract (OpenAPI or equivalent).
10. Epics, features and testable user stories.
11. Traceability matrix (requirement → story → test).
12. Test strategy, test plans, synthetic fixtures and test evidence.
13. Deployment, backup, recovery, monitoring and support runbooks.
14. User/admin training and change-management plan.
15. Release notes and known limitations.

## First instruction to Claude Code

Start in Plan Mode. Inspect the repository, installed BMad version, existing dependencies and available docs. Do not write application code yet. Create a repository assessment and report:

1. Greenfield or existing project status;
2. Current stack and repo structure (if present);
3. Existing documentation and gaps;
4. BMad version/workflows available for Claude Code;
5. Scope, security and governance risks;
6. Proposed next BMad workflow and artifacts;
7. Questions that require an authorised ZPS stakeholder.

Then stop for human review of the discovery output before progressing to implementation.
