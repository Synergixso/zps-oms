# ZPS-OMS — Phase 1 Documentation and Claude Code Pack

**Version:** 1.1  
**Issue date:** 25 November 2026  
**Status:** Prepared for institutional review; internal discovery and approvals remain outstanding.

## Project boundary

ZPS-OMS is a proposed administrative management platform for the Zambia Police Service Operations structure from Service Headquarters under the Deputy Inspector General – Operations (DIG Ops), through the ten Provincial Divisions and authorised DIG Ops Divisional Units/formations.

The product scope excludes districts, police stations, police posts and the separate national Training Management System. It also excludes tactical command, dispatch, operational plans, patrol routes, real-time officer tracking, intelligence, surveillance, informants, criminal case files, evidence/exhibits, firearms/armoury and sensitive operational capability data.

The exact internal establishment, titles, reporting links and authorised formation list are not yet institutionally validated. Public organograms are a desk-research baseline only. The current approved Zambia Police Service establishment must prevail.

## Zero-funding current-stage rule

No new project funding is requested or authorised for the current documentation, requirements refinement, UX exploration and local synthetic-data prototype stage. The approach assumes use of existing permitted tools and in-kind effort only. The present stage does not authorise procurement, travel, allowances, printing, paid software, subscription upgrades, external APIs, paid hosting, hardware purchase, production deployment or access to live police information.

If any tool, licence, API, cloud service, account upgrade, hardware or other activity requires payment, STOP. Do not spend, subscribe or procure. Record the requirement as an open decision for a later authorised stage.

This zero-additional-cash position applies only to the current stage. It is not a statement that production hosting, security assessments, operational support, devices, training or national rollout can be delivered indefinitely at no cost. Any later need must be separately assessed and approved.

## Safe development rule

- Use public information and wholly synthetic records only.
- Do not use real officer names, service numbers, personal data, phone numbers, vehicle plates, deployment information, locations or actual records.
- Do not connect to Zambia Police networks, identity providers, databases or internal systems.
- Keep repositories and prototype data local unless an authorised toolchain and repository destination are formally approved.
- Do not put police records, confidential documents or sensitive institutional information into Claude prompts, model context, extensions, telemetry, external repositories or third-party services.
- Do not build any excluded operational capability, even as a mock user-facing module.

## Files

- `CLAUDE.md` — global project instructions for Claude Code.
- `.claude/rules/` — scope and data-handling rules.
- `docs/phase1/` — phase charter, scope, organisation baseline, requirements, governance, data/security controls, zero-funding plan and exit gates.
- `prompts/` — sequential prompts for repository audit, discovery, PRD traceability, prototype planning and verification.
- `artifacts/phase1/` — controlled DOCX and XLSX documentation deliverables.

## Recommended sequence

1. Read `CLAUDE.md` and all Phase 1 documents.
2. Run `prompts/00-repository-audit-no-code.md` in Claude Code Plan Mode.
3. Reconcile gaps and source conflicts; do not generate application code yet.
4. Continue with the discovery and requirements validation prompts.
5. Only after written institutional approvals, decide whether to proceed to a local synthetic prototype.

This package does not constitute Zambia Police Service approval, procurement authority, production authorisation or permission to process police data.
