# Changelog

## v1.1 — 25 November 2026
- Consolidated Phase 1 institutional discovery, requirements, governance, data, security and verification documentation.
- Reaffirmed scope: DIG Ops Headquarters, ten Provincial Divisions and authorised DIG Ops Divisional Units/formations only.
- Kept district, station, post and separate training-system features outside scope.
- Added a zero-additional-cash current-stage development plan, no-procurement rule and stop conditions.
- Added RACI, candidate data inventory, test catalogue, Phase 1 exit gates and document register to the workbook.
- Updated legal desk references: ZambiaLII records the Data Protection Act 2021 commenced 1 April 2021 and the Cyber Security Act 2025 and Cyber Crimes Act 2025 commenced 12 May 2025. Legal review remains required.
- Highlighted Technical Services Directorate's published software, network, ICT support and mechanical/vehicle maintenance mandates to prevent duplicate systems.
- No internal interviews or institutional approvals are claimed as complete.
