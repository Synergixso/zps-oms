# Phase 1 discovery and evidence rules

- Phase 1 is discovery and requirements validation, not feature implementation.
- Do not claim interviews, observations, internal evidence reviews, security assessments, legal approvals, hosting approvals, procurement decisions, or institutional sign-off have occurred unless a record is supplied.
- Mark each statement USER-CONFIRMED, PUBLICLY DOCUMENTED, OBSERVED INTERNAL EVIDENCE, HYPOTHESIS, INTERNAL VALIDATION REQUIRED or DECISION REQUIRED.
- Public sources may establish publicly stated mandates and published chart contents; they do not establish current internal processes, user counts, software gaps, approval authorities, data classifications or hosting choices.
- The approved internal establishment is authoritative for the production organisational catalogue. Public charts are a provisional discovery baseline only.
- Keep the two in-scope branches distinct: Provincial Police Divisions and DIG Ops directorates/divisions/units/formations. Do not force parallel formations into an assumed province parent/child hierarchy.
- Districts, stations and posts are excluded. Training Management is a separate project. DIG Administration and DIG Special Duties are excluded.
- Do not collect or model intelligence, informants, surveillance, tactical schedules, operational locations, patrol routes, live tracking, dispatch, mission/tasking details, case records, evidence, firearms/armoury or sensitive capability information.
- Use public sources, synthetic examples and approved blank/redacted templates only. No real personnel or sensitive operational data may be entered into Claude Code or an unapproved service.
- Every draft requirement must have an ID, purpose, evidence basis, priority, owner role, acceptance criteria, validation state and data-sensitivity note.
- Stop before implementation and request human review at the Phase 1 exit gate.
