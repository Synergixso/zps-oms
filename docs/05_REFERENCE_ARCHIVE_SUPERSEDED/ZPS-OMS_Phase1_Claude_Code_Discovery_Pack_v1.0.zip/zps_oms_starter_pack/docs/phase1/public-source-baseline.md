# ZPS-OMS Public-Source Baseline

**Retrieved/reviewed:** 24 November 2026  
**Status:** Public-source desk research; internal confirmation pending.

| Ref | Official source | What it supports | Limitation |
|---|---|---|---|
| SRC-01 | https://zambiapolice.gov.zm/deputy-inspector-general-of-police-operations/ | DIG Ops remit; oversight of Provinces; list of Crime Prevention & Support Services Directorate, Paramilitary Battalion, TAZARA Division, Kamfinsa SPOM/Mobile Unit, Airport Division, Protective Unit, Police Air Wing and National Command Centre. | The page does not substitute for the current approved internal establishment. |
| SRC-02 | https://zambiapolice.gov.zm/wp-content/uploads/2025/05/appendix-d-organochart-office-of-the-deputy-inspector-general-operations.pdf | Appendix D depicts Deputy Police Commander (PSS01) → Commissioner of Police (PSS02) → eight parallel PSS03 positions. | Labels differ from the DIG Ops webpage. Confirm titles/reporting in writing. |
| SRC-03 | https://zambiapolice.gov.zm/organocharts/ | Index to public ZPS organograms. | Confirm the current approved chart/version internally. |
| SRC-04 | https://zambiapolice.gov.zm/the-divisional-office-province/ | Public provincial division mandate and structure. | The page contains district-level information; districts are excluded from ZPS-OMS. |
| SRC-05 | https://zambiapolice.gov.zm/the-paramilitary-battalion/ | Administrative, transport, maintenance and logistical functions appear in the public formation description. | Used only to justify administrative process discovery. Tactical capabilities are excluded. |
| SRC-06 | https://zambiapolice.gov.zm/the-tazara-division/ | Public TAZARA administrative and logistical support responsibilities. | Does not establish current workflows or software pain points. |
| SRC-07 | https://zambiapolice.gov.zm/the-protective-unit/ | Public Protective Unit structure/mandate. | Do not design or collect operational/security detail. |
| SRC-08 | https://zambiapolice.gov.zm/the-airport-division/ | Public Airport Division structure/mandate. | Do not design or collect operational/security detail. |
| SRC-09 | https://www.parliament.gov.zm/node/8853 | Data Protection Act, 2021 (Act No. 3 of 2021). | Obtain legal/privacy review of application and current requirements. |
| SRC-10 | https://www.parliament.gov.zm/node/12319 | Cyber Security Act, 2025 (Act No. 3 of 2025). | Confirm applicability, designation and current requirements with competent authority. |
| SRC-11 | https://www.parliament.gov.zm/sites/default/files/documents/acts/Acts%20No.%204%20of%202025%2C%20The%20Cyber%20Crimes.pdf | Cyber Crimes Act, 2025 (Act No. 4 of 2025). | The Act text includes a commencement provision; verify the relevant commencement instrument. |
| SRC-12 | https://www.parliament.gov.zm/node/9014 | Electronic Government Act, 2021 (Act No. 41 of 2021). | Confirm applicable government ICT approvals/standards. |
| SRC-13 | https://www.parliament.gov.zm/node/8634 | Public Procurement Act, 2020 (Act No. 8 of 2020). | Confirm current regulations/amendments and appropriate procurement route. |
| SRC-14 | https://www.dataprotection.gov.zm/wp-content/uploads/2025/03/Guide_Registration-of-Data-Controllers-and-Processors.pdf | Data Protection Commission registration guide for public bodies and contractors. | Verify actual controller/processor roles and registration status; do not assume. |

## Organisational discrepancy requiring formal resolution

The public DIG Ops webpage uses “Deputy Inspector General of Police – Operations” and says the office oversees Provinces and the listed formations. Appendix D uses “Deputy Police Commander (PSS01)” and “Commissioner of Police (PSS02)” before the eight PSS03 positions. The chart and web page do not fully resolve the internal title equivalence or all reporting relationships. The system must store organisational units and relationships as approved, effective-dated configuration; do not hard-code assumptions.
