# ZPS-OMS Phase 1 — Institutional Discovery and Requirements Validation

**Status:** Prepared for formal institutional validation  
**Version:** 1.0  
**Date:** 24 November 2026

This folder records the Phase 1 discovery baseline for the Zambia Police Service Operations Management System (ZPS-OMS). It is a planning artifact only. It does not represent an authorised police system, an approved requirements baseline, or permission to process live police information.

## Agreed product boundary

ZPS-OMS is limited to:

- The Office of the Deputy Inspector General – Operations (DIG Ops) at Service Headquarters, including approved intermediate roles in the current establishment.
- The ten Provincial Police Divisions.
- Directorates, divisions, units and formations formally confirmed as within DIG Ops remit.

Explicit exclusions:

- District offices, police stations and police posts.
- DIG Administration and DIG Special Duties structures.
- The separate national Police Training Management System.
- Intelligence, informants, surveillance, tactical deployment, patrol routes, live location tracking, dispatch, case files, evidence, armoury/firearms, and other sensitive operational capabilities.
- External ministry accounts or integrations unless later authorised through formal change control.

## Evidence labels

Every statement must be marked as one of:

- **USER-CONFIRMED** — directly stated as project scope or decision by the project requester.
- **PUBLICLY DOCUMENTED** — found in an official public institutional/government source.
- **OBSERVED INTERNAL EVIDENCE** — collected during an authorised interview, walk-through or approved artefact review.
- **HYPOTHESIS** — possible pain point or process issue not yet proven.
- **INTERNAL VALIDATION REQUIRED** — requires an approved internal document, decision or owner confirmation.
- **DECISION REQUIRED** — must be determined by an authorised institutional role.

Do not convert a hypothesis into a fact. Do not state that a workflow is manual, fragmented, slow or duplicated unless evidence supports it.

## Critical public-source observation

The official DIG Ops webpage describes the office as coordinating Police operations functions and overseeing Provinces plus eight named directorates/units/formations. The public Appendix D organogram shows a Deputy Police Commander (PSS01), a Commissioner of Police (PSS02), and eight parallel PSS03 subordinate positions. The web page and chart use different title labels/presentations. The current approved establishment and chart must be obtained before application hierarchy or permissions are implemented.

## Phase 1 work products

See the accompanying Phase 1 report and tracker in `artifacts/phase1/`, and the question/prompts under `prompts/phase1/`.
