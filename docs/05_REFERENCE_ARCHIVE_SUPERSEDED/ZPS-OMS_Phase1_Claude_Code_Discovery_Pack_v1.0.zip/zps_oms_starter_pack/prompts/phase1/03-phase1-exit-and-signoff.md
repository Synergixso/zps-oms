# Claude Code Prompt — Phase 1 Exit and Sign-off Pack

**Mode:** Plan Mode. Documentation-only.

Review the final Phase 1 evidence log, organisation register, stakeholder map, current-state process maps, pain-point register, requirements catalogue, data inventory, legal/privacy/security actions, technical constraints, risk register and decision log.

Prepare a Phase 1 exit pack with:
1. items validated with evidence;
2. items still open and the reason;
3. requirements accepted, amended, rejected or deferred;
4. unresolved organisational title/reporting questions;
5. unresolved data, hosting, identity, retention, support and procurement decisions;
6. proposed MVP candidate scope with explicit exclusions;
7. pilot selection evidence and baseline metrics still required;
8. residual risks and accountable owner roles;
9. a formal decision template: Approved / Approved with Actions / Return for Rework / Not Approved.

Do not mark the phase complete or approved unless a signed institutional decision record is present. Stop before moving to BMad Planning.
