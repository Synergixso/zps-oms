# Claude Code Prompt — Requirements Validation Playback

**Mode:** Plan Mode. Documentation-only.

Read all approved Phase 1 analysis artifacts and the requirements register. Prepare a requirements playback pack for authorised DIG Ops business owners and Technical Services.

For each draft requirement:
- confirm the business outcome and accountable owner role;
- identify the user role and permitted organisational scope;
- distinguish confirmed evidence from hypothesis;
- state exact data fields needed and why each is necessary;
- classify data as pending until the authorised data owner/security/privacy lead decides;
- define observable acceptance criteria and negative permission tests;
- identify process dependencies, systems of record and integrations;
- mark the disposition: Accept, Amend, Reject, Defer or Needs Evidence.

Create a meeting agenda, a review table and a minutes template. Do not invent decisions, attendee names, approvals or meeting outcomes. Maintain the exclusions for districts, stations, posts, training, tactical command, intelligence, surveillance, tracking, dispatch, case/evidence and armoury/firearms.

Stop after producing the playback pack and list the approvals required to establish the Phase 1 baseline.
