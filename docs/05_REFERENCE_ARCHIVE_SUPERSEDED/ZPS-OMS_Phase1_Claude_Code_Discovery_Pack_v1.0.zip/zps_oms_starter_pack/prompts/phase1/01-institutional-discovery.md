# Claude Code Prompt — Phase 1 Institutional Discovery

**Mode:** Plan Mode. Documentation-only. Do not write application code.

You are the institutional discovery analyst and solution architect for ZPS-OMS. First read `CLAUDE.md`, `.claude/rules/scope.md`, `.claude/rules/security.md`, `.claude/rules/phase1-discovery.md`, the Master PRD and all available Phase 1 documents.

## Scope

ZPS-OMS covers only the Office of DIG Operations at Service Headquarters, the ten Provincial Police Divisions, and directorates/divisions/units/formations formally confirmed as within the DIG Ops remit. District offices, police stations and police posts are excluded. The separate national Training Management System is excluded. Ministry users are not assumed to be system users.

## Tasks

1. Inspect the repository structure, current technology, local BMad Method installation/version/workflows and project documentation. Do not expose secrets or print environment values.
2. Review the official public source baseline recorded in `docs/phase1/public-source-baseline.md`. If external browsing is available and authorised, verify source URLs and retrieval dates. Do not infer internal facts from public content.
3. Create/update `docs/analysis/` artifacts: product brief, stakeholder map, organisation verification register, source register, assumptions register, open decisions, risk register, current-state process catalogue, pain-point hypothesis register and repository assessment.
4. Create an evidence log with explicit evidence class: USER-CONFIRMED, PUBLICLY DOCUMENTED, OBSERVED INTERNAL EVIDENCE, HYPOTHESIS, INTERNAL VALIDATION REQUIRED or DECISION REQUIRED.
5. Build the stakeholder interview plan and question bank. Do not invent names or claim interviews have occurred.
6. Record the public Appendix D discrepancy: public DIG Ops webpage vs Appendix D title labels/intermediate Commissioner PSS02; mark internal establishment confirmation as P0.
7. Create a preliminary traceability approach from pain point → process → requirement → story → test.
8. List the exact evidence needed from authorised ZPS role holders. Request only approved current org charts, role descriptions, delegation schedules, blank/redacted forms, data dictionaries, system inventories and technical policies. Do not request tactical plans, operational schedules, location data, intelligence, case files or live personnel records.

## Constraints

- Use synthetic data only.
- Do not implement features, database schemas or integrations in this session.
- Do not choose hosting, identity provider, data retention periods, pilot site or procurement method without approved evidence.
- Do not assert that manual or fragmented processes exist without evidence.
- Preserve all hard exclusions from project rules.

## Output

Provide a concise discovery report, artifacts created, source list, unresolved decisions, risks, and recommended next BMad workflow. Identify which items need human/institutional validation. Stop for review; do not proceed to Planning without explicit approval.
