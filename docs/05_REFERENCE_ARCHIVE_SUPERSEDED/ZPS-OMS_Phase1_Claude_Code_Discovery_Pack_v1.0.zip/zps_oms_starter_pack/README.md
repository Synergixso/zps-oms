# ZPS-OMS Claude Code Starter Pack

This starter pack contains planning and instruction files for a proposed Zambia Police Service Operations Management System (ZPS-OMS).

## Included
- `CLAUDE.md` — concise persistent project context for Claude Code.
- `.claude/rules/scope.md` — fixed organisational boundary and exclusions.
- `.claude/rules/security.md` — non-negotiable security and data-handling rules.
- `.claude/skills/quality-gate/SKILL.md` — repeatable quality gate procedure.
- `prompts/master-project-prompt.md` — full CLEAR-structured project prompt for Claude Code.
- `prompts/01-discovery-session.md` — first-session discovery instructions.
- `prompts/02-prd-session.md` — BMad PRD creation/validation prompt.
- `prompts/03-implement-story.md` — controlled story implementation prompt.
- `docs/initial-scope-baseline.md` — confirmed scope baseline and open validation needs.
- `docs/README.md` — documentation register.

## Start
1. Create/open a dedicated, access-controlled repository with no police data.
2. Copy these files into the repository root, preserving hidden `.claude` folders.
3. Open Claude Code in that repository.
4. Start in Plan Mode and use `prompts/01-discovery-session.md`.
5. Install/initialise BMad only after reviewing the current stable installation instructions and repository impact. The current official stable BMad Method page checked on 24 November 2026 showed v6.12.0 and `npx bmad-method install`; recheck before running.
6. Do not begin production development or use real records until the required institutional approvals are documented.

## Important
This is not a production-ready system, not a police approval, and not a substitute for institutional legal/security review. Use synthetic data only. The system scope excludes districts, stations, posts and sensitive operational capabilities.

## Phase 1 — Institutional Discovery and Requirements Validation

The current Phase 1 package is under `docs/phase1/`, with Claude Code execution prompts under `prompts/phase1/` and the editable report/tracker under `artifacts/phase1/`. Run `prompts/phase1/01-institutional-discovery.md` in Plan Mode. Do not implement application features until discovery and requirements are formally reviewed and approved.
