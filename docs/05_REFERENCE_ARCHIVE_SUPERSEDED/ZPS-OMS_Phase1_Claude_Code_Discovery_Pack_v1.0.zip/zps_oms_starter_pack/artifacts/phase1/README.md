# Phase 1 deliverables

Place the approved copies of the following artifacts here:

- `ZPS-OMS_Phase1_Institutional_Discovery_and_Requirements_Validation_v1.0.docx` — current desk-based discovery report, prepared for internal validation.
- `ZPS-OMS_Phase1_Requirements_and_Discovery_Tracker_v1.0.xlsx` — editable organisation, requirements, stakeholders, processes, decisions, assumptions/risks, interview, source and validation registers.

Do not replace these with a version marked “approved” until the relevant institutional signatories have reviewed and accepted the content.
